<?php

return [
    "mtn_bj" => ["MTN Mobile Money Bénin", "XOF"],
    "orange_sn" => ["Orange Money Sénégal", "XOF"],
    "wave_sn" => ["Wave Sénégal", "XOF"],
    "orange_ci" => ["Orange Money Côte d'Ivoire", "XOF"],
    "mtn_ci" => ["MTN MoMo Côte d'Ivoire", "XOF"],
    "wave_ci" => ["Wave Côte d'Ivoire", "XOF"],
    "moneroo_payout_demo" => ["Transfert Demo Moneroo", "XOF"],
    "orange_cm" => ["Orange Money Cameroon", "XAF"],
    "mtn_cm" => ["MTN Mobile Money Cameroon", "XAF"],
];