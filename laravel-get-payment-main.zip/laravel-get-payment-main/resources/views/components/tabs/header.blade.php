<div class="flex gap-2 border-b">
    {{ $slot }}
</div>
