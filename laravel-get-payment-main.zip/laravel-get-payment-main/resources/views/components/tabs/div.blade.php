<div x-show="active === @js($name)" class="p-4">
    {{ $slot }}
</div>